// import of views
import NotFound from "../views/notFound.js";
import Events from "../views/events.js";
import Login from "../views/login.js";
import Register from "../views/register.js";
import AccessDenied from "../views/accessDenied.js";
// import of auth
import {
  isAutenticated,
  updateAuthButtons,
  validateGuardedPath,
  getUserRole,
} from "../js/auth.js";
// import of login, register and events functionality
import setupLogin from "../js/loginScript.js";
import setupRegister from "../js/registerScript.js";
import setupEvents from "../js/eventsScript.js";

// route definition
const routes = {
  "/": {
    view: Login,
    guarded: validateGuardedPath("/"),
    script: setupLogin,
    roles: [],
  },
  "/events": {
    view: Events,
    guarded: validateGuardedPath("/events"),
    script: setupEvents,
    roles: [],
  },
  "/register": {view: Register, 
    guarded: validateGuardedPath("/register"), 
    script: setupRegister,
    roles:[]}
};

export function router() {
  const path = window.location.pathname;
  const route = routes[path] || { view: NotFound, guarded: false, roles: [] };
  updateAuthButtons();

  //obtain user role
  const currentUserRole = getUserRole();

  // management of routes protected by authentication
  if (route.guarded && !isAutenticated()) {
    history.pushState(null, null, "/");
    return router();
  }
  
  // management of protected routes by role
  // role logic only applies if the route is marked as guarded and has specific roles.
  if (route.guarded && route.roles && route.roles.length > 0) {
    if (!currentUserRole || !route.roles.includes(currentUserRole)) {
      //if the user has no role or his role is not in the list of roles, displays access denied view
      document.getElementById("app").innerHTML = AccessDenied();
      return;
    }
  }

  document.getElementById("app").innerHTML = route.view();

  if (route.script) {
    route.script();
  }

  
}
