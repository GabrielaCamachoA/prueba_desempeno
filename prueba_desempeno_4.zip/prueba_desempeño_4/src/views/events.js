export default function Events() {
  return `<div id="eventsContainer"></div>`;
}
