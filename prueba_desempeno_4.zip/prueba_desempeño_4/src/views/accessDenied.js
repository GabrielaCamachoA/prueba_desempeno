export default function AccessDenied() {
  return `<h1 class="h1">Acceso denegado</h1>`;
}
