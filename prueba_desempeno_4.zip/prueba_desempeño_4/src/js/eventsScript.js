import { router } from "../routes/router";

// this is the function that will be called in router, in the Events view
export default function setupEvents() {
  renderEvents();
}

// this function displays all events depending on the user role
async function showEvents() {
  try {
    // the events and registraions in the db.json file are queried
    const eventosRes = await fetch("http://localhost:3000/events");
    const eventos = await eventosRes.json();

    const registersRes = await fetch("http://localhost:3000/registers");
    const registers = await registersRes.json();

    //the data of the user who has already registered are obtained
    const authData = JSON.parse(localStorage.getItem("auth_token"));
    if (!authData) {
      history.pushState(null, null, "/");
      return router();
    }
    const user = authData.user;
    const rol = authData.rol;

    //here you will see the html of the container where the events will be displayed
    const $container = document.getElementById("app");
    let html = `<h2 class="h3"> Welcome ${user}</h2>`;

    // if the user is admin the btn is authorized to create a new event
    if (rol === "admin") {
      html += `<button id="btnCrearEvento" class="btn btn-success mb-3">Create event</button>`;
    }

    //html where cards will be stored and card creation
    html += `<div class=" d-flex flex-column justify-content-center">`;

    eventos.forEach((e) => {
      const inscritos = registers.filter((r) => r.eventoId === e.id).length;
      const yaRegistrado = registers.some(
        (r) => r.eventoId === e.id && r.user === user
      );
      const capacidad = parseInt(e.capacidad);

      html += `
        <div class=" row-cols-1 g-3">
          <div class="card shadow-sm border-0 rounded-4 mb-4">
            <div class="card-body">
              <h4 class="card-title fw-bold text-primary">${e.name}</h4>
              <p class="text-muted">${e.descrp}</p>
              <ul class="list-group list-group-flush mb-3">
                <li class="list-group-item">Capacidad máxima: <strong>${capacidad}</strong></li>
                <li class="list-group-item">Registrados: <strong>${inscritos}</strong></li>
                <li class="list-group-item">Fecha: <strong>${e.fecha}</strong></li>
              </ul>`;

      // if the user is admin the edit and delete course buttons are enabled
      if (rol === "admin") {
        html += `
          <button class="btn btn-outline-primary btn-sm rounded-pill" data-action="editar" data-id="${e.id}">
            Editar
          </button>
          <button class="btn btn-outline-danger btn-sm rounded-pill" data-action="eliminar" data-id="${e.id}">
            Eliminar
          </button>`;
        // if the user is a visitor, the button to register in the courses is enabled.
      } else if (rol === "visitante") {
        if (yaRegistrado) {
          html += `<p class="text-success"><strong>Ya estás registrado</strong></p>`;
        } else if (inscritos >= capacidad) {
          html += `<p class="text-danger"><strong>Evento lleno</strong></p>`;
        } else {
          html += `<button class="btn btn-primary btn-sm" data-action="registrarse" data-id="${e.id}">
            Registrarse
          </button>`;
        }
      }

      html += `</div></div></div>`;
    });

    html += `</div>`;
    $container.innerHTML = html;
    // the data-action attribute is called in order to give functionality to the edit and delete buttons
    document.querySelectorAll("[data-action='editar']").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        const eventoId = e.target.getAttribute("data-id");

        // a request is made in order to obtain the event to be updated.
        try {
          const res = await fetch(`http://localhost:3000/events/${eventoId}`);
          if (!res.ok) throw new Error("No se pudo cargar el evento");

          const evento = await res.json();
          renderForm(evento); // this function is called to pass the new data from the event
        } catch (err) {
          console.error(err);
          alert("Error al cargar el evento");
        }
      });
    });

    // delte button
    document.querySelectorAll("[data-action='eliminar']").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        const eventoId = e.target.getAttribute("data-id");

        const confirmacion = confirm(
          "¿Seguro que deseas eliminar este evento?"
        );
        if (!confirmacion) return;
        // request to remove events
        try {
          const res = await fetch(`http://localhost:3000/events/${eventoId}`, {
            method: "DELETE",
          });
          if (!res.ok) throw new Error("No se pudo eliminar el evento");

          alert("Evento eliminado correctamente");
          showEvents(); // Update the event list
        } catch (err) {
          console.error(err);
          alert("Error al eliminar evento");
        }
      });
    });

    // if the user is an admin he can create events
    if (rol === "admin") {
      document
        .getElementById("btnCrearEvento")
        .addEventListener("click", () => {
          renderForm(); // the form function is called to create events
        });
    }

    // Capturing clicks for visitor registration at an event
    document.querySelectorAll("[data-action='registrarse']").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        const eventoId = e.target.getAttribute("data-id");
        try {
          const nuevoRegistro = {
            eventoId,
            user,
          };
          const res = await fetch("http://localhost:3000/registers", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(nuevoRegistro),
          });

          if (!res.ok) throw new Error("Error al registrar");

          alert("Registro exitoso");
          showEvents(); // Reload view to show that you are already registered in the event.
        } catch (err) {
          console.error(err);
          alert("Ocurrió un error al registrarse");
        }
      });
    });
  } catch (error) {
    console.error("Error al mostrar eventos:", error);
  }
}

// function to display the form for editing or creating an event
function renderForm(evento = null) {
  const isEditing = evento !== null;
  const titulo = isEditing ? "Editar Evento" : "Crear Evento";

  document.getElementById("app").innerHTML = `
    <div class="container mt-5">
      <h2>${titulo}</h2>
      <form id="form">
        <input type="text" id="name" class="form-control mb-2" placeholder="Nombre" value="${
          evento?.name || ""
        }" />
        <input type="text" id="descrp" class="form-control mb-2" placeholder="Descripción" value="${
          evento?.descrp || ""
        }" />
        <input type="text" id="fecha" class="form-control mb-2" placeholder="Fecha" value="${
          evento?.fecha || ""
        }" />
        <input type="text" id="capacidad" class="form-control mb-2" placeholder="Capacidad" value="${
          evento?.capacidad || ""
        }" />
        <button id="newEvent" class="btn btn-primary">${
          isEditing ? "Actualizar" : "Crear"
        }</button>
      </form>
    </div>
  `;
// updated event data
  document.getElementById("form").onsubmit = async (e) => {
    e.preventDefault();
    const eventoActualizado = {
      name: e.target.name.value,
      descrp: e.target.descrp.value,
      fecha: e.target.fecha.value,
      capacidad: e.target.capacidad.value,
    };
// updates or new event are uploaded to the db.json file
    try {
      const url = isEditing
        ? `http://localhost:3000/events/${evento.id}`
        : "http://localhost:3000/events";

      const method = isEditing ? "PUT" : "POST";

      const response = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(eventoActualizado),
      });

      if (!response.ok) throw new Error("Error al guardar evento");

      const data = await response.json();
      alert(isEditing ? "Evento actualizado" : "Evento creado");

      showEvents(); // Reload events
    } catch (error) {
      console.error(error);
      alert("Hubo un problema al guardar el evento");
    }
  };
}

// start the btnCreateEvent events
function renderEvents() {
  const btnCrear = document.getElementById("btnCrearEvento");
  if (btnCrear) {
    btnCrear.addEventListener("click", () => {
      renderForm();
    });
  }

  showEvents();
}

renderEvents();