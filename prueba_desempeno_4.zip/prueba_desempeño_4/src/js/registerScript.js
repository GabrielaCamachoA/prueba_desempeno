// imports
import { hashPassword, register } from "./auth";
import { router } from "../routes/router";

// function to register new users
export default function setupRegister() {
  const $registerBtn = document.getElementById("registerBtn");
  if (!$registerBtn) return;

  if ($registerBtn) {
    $registerBtn.addEventListener("click", async (e) => {
      e.preventDefault();
      // user data is captured
      const user = document.getElementById("username").value.trim();
      const pass = document.getElementById("password").value.trim();
      const confirmPassword = document.getElementById("confirmPassword").value.trim();

      // data validations
      if (!user || !pass || !confirmPassword) {
        alert("Todos los campos son obligatorios.");
        return;
      }

      if (pass !== confirmPassword) {
        alert("Las contraseñas no coinciden.");
        return;
      }

      let passHashed = hashPassword(pass);
      // new object to be displayed in the db.json file
      const newUser = {
        username: user,
        password: passHashed,
        rol: "visitante",
      };
      // method post to save
      try {
        const response = await fetch("http://localhost:3000/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newUser)
      });

      if (!response.ok) throw new Error("Error al registrar usuario");
      const savedUser = await response.json();

      // stores the user data in localStorage
      register("fake_token", savedUser.username, passHashed, savedUser.rol);
      // change URL to “/events” without reloading page
      history.pushState(null, null, "/events");
      router();
    } catch (error) {
      console.error(error);
      alert("Error al registrar usuario");
    }
  });
  }
}
