// imports
import { hashPassword, login, validateCredentials } from "../js/auth.js";
import { router } from "../routes/router.js";

// this function will log users in
export default function setupLogin() {
  const $btn = document.getElementById("loginBtn");
  if (!$btn) return;

  if ($btn) {
    $btn.addEventListener("click", (e) => {
      e.preventDefault();
      // by means of an addEventListener the user and pass ids are saved, also the hashed password
      const user = document.getElementById("username").value.trim();
      const pass = document.getElementById("password").value.trim();

      let passHashed = hashPassword(pass);

      // request to obtain users
      const getAllUsers = async () => {
        const URL_API = "http://localhost:3000/users";
        try {
          let resConsulta = await fetch(URL_API);
          let usersJson = await resConsulta.json();
          // error handling
          if (!resConsulta.ok)
            throw {
              status: resConsulta.status,
              statusText: resConsulta.statusText,
            };
          // if there are no errors, returns the users from db.json file
          alert("get correcto")
          return usersJson;
        } catch (error) {
          let message = error.statusText || "Ocurrio un error";
          alert(message);
        }
      };

      // user validation
      async function startSession() {
        const users = await getAllUsers();

        if (!users) {
          return;
        }

        let userFound = null;
        console.log(users);
        
        // all users are checked to make sure that they are registered.
        users.forEach((e) => {
          if (e.username.toLowerCase() === user.toLowerCase()) {
            userFound = e;
          }
        });

        if (!userFound) {
          alert("Usuario no registrado");
          return;
        }

        const isValid = validateCredentials(user, pass, userFound);
        if (!isValid) {
          return;
        }

        // log in if all is well
        login("fake_token", user, passHashed, userFound.rol);

        history.pushState(null, null, "/events");
        router();
      }

      startSession();
    });
  }
}