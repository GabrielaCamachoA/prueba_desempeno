// import crypto library for password encryption
import CryptoJS from "crypto-js";

// function to check if the user is authenticated
export function isAutenticated() {
  return localStorage.getItem("auth_token") !== null;
}

// function to obtain user role
export function getUserRole() {
  const authToken = localStorage.getItem("auth_token");
  if (authToken) {
    try {
      const userData = JSON.parse(authToken);
      return userData.rol;
    } catch (error) {
      console.error("Error obtener data del localStorage", error);
      return null;
    }
  }
  return null;
}
// function to switch buttons when user is authenticated or not authenticated
// is done with css styles to remove and show them.
export function updateAuthButtons() {
  const $btnLogin = document.getElementById("btnLogin");
  const $btnLogout = document.getElementById("btnLogout");
  const $btnRegister = document.getElementById("btnRegister")
  const $btnEvents= document.getElementById("btnEvents");
  const $h1= document.getElementById("h1");

  if (!$btnLogin || !$btnLogout || !$btnRegister) {
    console.warn(
      "Uno o ambos botones de autenticación (btnLogin, btnLogout) no se encontraron en el DOM."
    );
    return;
  }

  if (isAutenticated()) {
    $btnLogin.style.display = "none";
    $btnRegister.style.display = "none";
    $h1.style.display = "inline";
    $btnEvents.style.display = "inline";
    $btnLogout.style.display = "inline";
  } else {
    $btnLogin.style.display = "inline";
    $btnRegister.style.display = "inline";
    $h1.style.display = "none";
    $btnEvents.style.display = "none";
    $btnLogout.style.display = "none";
  }
}

//user registration function
export function register(token, user, pass, rol) {
  localStorage.setItem(
    "auth_token",
    JSON.stringify({
      token,
      user,
      pass,
      rol,
    })
  );
  updateAuthButtons();
}

// function for the user to log in
export function login(token, user, pass, rol) {
  localStorage.setItem(
    "auth_token",
    JSON.stringify({
      token,
      user,
      pass,
      rol,
    })
  );
  updateAuthButtons();
}

// logout function
export function logout() {
  localStorage.removeItem("auth_token");
  updateAuthButtons();
  window.location.reload();
}

// function to validate credentials
export function validateCredentials(user, pass, userApi) {
  const username = user.trim();
  const password = pass.trim();
  // from line 96 to line 119 validations are made to check 
  // that the fields are not empty, if the user is 
  // already registered or if the password is incorrect.
  if (!username && !password) {
    alert("por favor ingrese usuario y contraseña");
    return false;
  }
  if (!username) {
    alert("por favor ingrese usuario");
    return false;
  }
  if (!password) {
    alert("por favor ingrese password");
    return false;
  }
  if (username.toLowerCase() !== userApi.username.toLowerCase()) {
    alert("Usuario invalido - no registrado");
    return false;
  }

  const decryptedPass = decryptPassword(userApi.password);
  if (password !== decryptedPass) {
    alert("Contraseña incorrecta");
    return false;
  }
  // if it passes all validations
  return true;
}

// password hashing function with SHA-256 algorithm and crypto library
export function hashPassword(password) {
  const clave = "Clavesecreta123";
  // the message is encrypted using AES
  const passCifrada = CryptoJS.AES.encrypt(password, clave).toString();
  return passCifrada;
}

// function to un-hash password to validate at login
export function decryptPassword(passHashed) {
  const clave = "Clavesecreta123";
  const passDecrypt = CryptoJS.AES.decrypt(passHashed, clave);
  return passDecrypt.toString(CryptoJS.enc.Utf8);
}

// validate if the route is protected
export function validateGuardedPath(path) {
  switch (path) {
    case "/":
      return false;
    case "/events":
      return true;
    case "/register":
      return false;
    default:
      return false;
  }
}
