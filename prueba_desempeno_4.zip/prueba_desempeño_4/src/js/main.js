// router function import y logout 
import { router } from "../routes/router";
import { logout } from "./auth";

document.addEventListener("includes-loaded", () => {
  // router is run initially
  router();

  // clicks on the page are recorded.
  document.addEventListener("click", (e) => {
    let $btnLogout = document.getElementById("btnLogout");
    if (e.target.matches("[data-link]")) {
      e.preventDefault();
      history.pushState(null, null, e.target.href);
      router();
    }
    // if the btnLogout is clicked the logout() function is called
    if (e.target === $btnLogout) {
      console.log("click en logout");
      logout();
    }
  });
  //  navigation control with back/forward buttons
  window.addEventListener("popstate", router);
});
