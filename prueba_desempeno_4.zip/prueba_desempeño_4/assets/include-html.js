/**
  library to include html in my index dynamically
 */

document.addEventListener("DOMContentLoaded", (e) => {
  // we select all DOM elements that contain the attribute: data-include
  const $elements = document.querySelectorAll("[data-include]");
  // counter of items that have already been processed successfully or with error
  let loadedCount = 0;
  // total de elementos que tienen el atributo data-include en el DOM
  const total = $elements.length;

  if (total === 0) {
    document.dispatchEvent(new Event("includes-loaded"));
    return;
  }

  /**
 
 * iterates over each element asynchronously to make the fetch query with async and await
 * variables:
 *urlQuery: it comes in data-include of my elements
 * - resQuery: is a HTML formatted file
 * -html: value of resQuery which is converted to text
 */

  $elements.forEach(async (el) => {
    const urlConsulta = el.getAttribute("data-include");

    try {
      const resConsulta = await fetch(urlConsulta);
      const html = await resConsulta.text();

      if (!resConsulta.ok)
        throw { status: res.status, statusText: res.statusText };
      el.outerHTML = html;
    } catch (error) {
      let mensaje = error.statusText || "Ocurrio un error";
      el.outerHTML = `<p><b>Error: ${error.status} - ${mensaje}</b></p>`;
    } finally {
      loadedCount++;
      if (loadedCount === total) {
        document.dispatchEvent(new Event("includes-loaded"));
      }
    }
  });
});
