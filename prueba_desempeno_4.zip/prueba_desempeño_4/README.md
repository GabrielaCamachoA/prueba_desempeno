# Event management
## Description
1. Implementation with simulated APIs and
CRUD operations using JavaScript.
2.  HTTP methods, JSON data handling, and the use of the Fetch API are used to interact with
servers.
3. SPA project created in vite.


## Technologies

1. HTML 
2. Bootstrap 5
3. JavaScript
4. JSON
5. Vite / Node.JS

## Project structure
```
PRUEBA_DESEMPEÑO_4/
├── assets/
|  ├── footer.html
|  ├── header.html
|  ├── include-html.js
├── database/
|  ├── db.json
|  ├── mpassword.txt
├── node_modules/
├── src/
|  ├── js/
|  ├── auth.js
|  ├── eventsScript.js
|  ├── loginScript.js
|  ├── main.js
|  ├── registerScript.js
|  ├── routes/
|  ├── router.js
|  ├── views/
|  ├── accesDenied.js
|  ├── events.js
|  ├── login.js
|  ├── notFound.js
|  ├── register.js
├── index.html
├── package-lock.json
├── package.json
└── README.md

```

## Requirements
### Authentication system
- User registration with two roles: administrator and visitor.
-  Login for registered users.
- Route protection by means of a guardian in Router.js.
### Session persistence
- Use of Local Storage to maintain the logged in session and guarantee the
user experience.
- When logging in, user information must be stored in Local Storage to
maintain the session.
- Session must persist even on page reload.
### Data consistency
- The application must correctly synchronize CRUD operations with the simulated
database (json-server).
### User interface
- The SPA should be responsive and provide a smooth user experience.
- There should be intuitive forms for registration and login, as well as for managing
events.

## Type of users
### Administrator user:
-  In the db.json file, there must be a user with the role of administrator by
default. This user will be able to log in with this role.
-  The administrator user shall have the capabilities to edit and delete events.
### Visitor user:
- Visitors will be able to register for events as long as
has not exceeded the event capacity.
- In the same view, visitors will be able to view their event registrations.

## Installation
### This is to execute the json file:
1.  Open the terminal and run the following command:
- cd database
- json-server --watch db.json.
### This is to execute the project:
2.  Open another terminal window and run the command: npm run dev.


## Autor
- Gabriela Camacho Acosta
- Clan: Macondo
- Email: gabrielacacosta31@gmail.com