import { hashPassword, validateCredentials, register } from "./auth";
import { router } from "../routes/router";

export default function setupRegister() {
    const $registerBtn = document.getElementById("registerBtn");
    if (!$registerBtn) return;

    if ($registerBtn) {
        $registerBtn.addEventListener("click", (e) => {
            e.preventDefault();
            const user = document.getElementById("username").value.trim();
            const pass = document.getElementById("password").value.trim();

            let passHashed = hashPassword(pass);

            const newUser= {
                username: user,
                password:passHashed,
                rol:user
            }
            //post en api
            const postUsers = async () => {
                fetch("http://localhost:3000/users", {
                    method: 'POST',
                    headers : { 'Content-Type': 'application/json' },
                    body: JSON.stringify(newUser)
                })
                .then(response => response.json())
                .then(data => {
                    console.log("Usuario agregado: ", data);
                })
                .catch(error => console.error("Error al agregar el usuario:", error));
            }

            async function startSession() {
                const users = await postUsers();

                if (!users) {
                    return;
                }
                let userFound = null;

                users.forEach(element => {
                    if (element.username.toLowerCase() === user.toLowerCase()) {
                        userFound = element;
                    }
                });
                if (!userFound) {
                    alert("Usuario no registrado");
                    return;
                }

                const isValid = validateCredentials(user, pass, userFound);
                if (!isValid) {
                    return;
                }

                register("fake_token", user, passHashed, userFound.rol);
                history.pushState(null, null, "/events")
                router();
            }
            startSession();
        })
    }
}