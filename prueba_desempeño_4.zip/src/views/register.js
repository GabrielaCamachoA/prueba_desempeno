export default function Register() {
    return `
      <div class="container mt-5">
        <h2>Register</h2>
        <input type="text" id="username" class="form-control mb-2" placeholder="Usuario" />
        <input type="password" id="password" class="form-control mb-2" placeholder="Contraseña" />
        <input type="password" id="password" class="form-control mb-2" placeholder="Confirmar Contraseña" />
        <button id="registerBtn" class="btn btn-primary">Register</button>
      </div>
    `;
  }