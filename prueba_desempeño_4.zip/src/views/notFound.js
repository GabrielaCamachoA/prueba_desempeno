export default function NotFound() {
  return `<h1 class="h1">Not Found</h1>`;
}
