// importacion de vistas
import NotFound from "../views/notFound.js";
import Events from "../views/events.js";
import Login from "../views/login.js";
import Register from "../views/register.js";
import AccessDenied from "../views/accessDenied.js";

import {
  isAutenticated,
  updateAuthButtons,
  validateGuardedPath,
  getUserRole,
} from "../js/auth.js";
import setupLogin from "../js/loginScript.js";
import setupRegister from "../js/registerScript.js";

// definicion de rutas disponibles en la aplicacion
const routes = {
  "/login": {
    view: Login,
    guarded: validateGuardedPath("/login"),
    script: setupLogin,
    roles: [],
  },
  "/events": {
    view: Events,
    guarded: validateGuardedPath("/events"),
    roles: [],
  },
  "/register": {view: Register, 
    guarded: validateGuardedPath("/register"), 
    script: setupRegister,
    roles:[]}
};

export function router() {
  const path = window.location.pathname;
  const route = routes[path] || { view: NotFound, guarded: false, roles: [] };
  updateAuthButtons();

  //obtener rol de usuario
  const currentUserRole = getUserRole();

  // manejo de rutas protegidas por autenticacion
  if (route.guarded && !isAutenticated()) {
    history.pushState(null, null, "/login");
    return router();
  }
  
  // manejo de rutas protegidas por rol
  // solo se aplica la logica de rol su la ruta esta marcada como guarded y tiene roles especificos
  if (route.guarded && route.roles && route.roles.length > 0) {
    if (!currentUserRole || !route.roles.includes(currentUserRole)) {
      //si el usuario no tiene rol o su rol no esta en la lista de roles, muestra vista de acceso denegado
      document.getElementById("app").innerHTML = AccessDenied();
      return;
    }
  }

  document.getElementById("app").innerHTML = route.view();

  if (route.script) {
    route.script();
  }
  function renderEvents() {
    document.getElementById("app").innerHTML = Events();
    document.getElementById("btnCrearEvento").addEventListener("click", ()=>{
      renderForm();
    })
    showEvents();
  }
  function renderForm() {
    document.getElementById("app").innerHTML= `
  <div class="container mt-5">
    <h2>Crear Evento</h2>
    <form id="form">
    <input type="text" id="name" class="form-control mb-2" placeholder="Nombre" />
    <input type="text" id="descrp" class="form-control mb-2" placeholder="Descripción" />
   <input type="text" id="fecha" class="form-control mb-2" placeholder="Fecha" />
   <input type="text" id="capacidad" class="form-control mb-2" placeholder="Capacidad" />
    <button id="newEvent" class="btn btn-primary">Crear</button>
    </form>
  </div>
  `;
  document.getElementById("form").onsubmit = async e =>{
    e.preventDefault();
    const evento = {
      name: e.target.name.value,
      descrp: e.target.descrp.value,
      fecha: e.target.fecha.value,
      capacidad: e.target.capacidad.value
    };
    try {
      const response = await fetch("http://localhost:3000/events", {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(evento)
    });
    const data = await response.json();
    console.log("Evento agregado", data);
    renderForm();
    } catch (error) {
      console.error("Error al crear evento", error);
      
    }
    }
  }
  renderEvents();

  async function showEvents() {
    try {
      const eventos = await fetch("http://localhost:3000/events");
      const data = await eventos.json();
      console.log(data);
      document.getElementById("app").innerHTML = `
      <div class="card shadow-sm border-0 rounded-4 mb-4">
      ${data.map(e => ` <div class="card-body">
        <div class="d-flex justify-content-between align-items-start">
          <div>
            <h4 class="card-title fw-bold text-primary">${e.name}</h4>
            <p class="text-muted">${e.descrp}</p>
            <ul class="list-group list-group-flush mb-3">
              <li class="list-group-item">Capacidad máxima: <strong>${e.capacidad} estudiantes</strong></li>
              <li class="list-group-item">Fecha del curso: <strong>${e.fecha}</strong></li>
            </ul>
          </div>

          <div class="d-flex flex-column gap-2">
            <button class="btn btn-outline-primary btn-sm rounded-pill" data-accion="editar" data-id="3">
              Editar
            </button>
            <button class="btn btn-outline-danger btn-sm rounded-pill" data-accion="eliminar" data-id="3">
              Eliminar
            </button>
          </div>
        </div>
      </div> `)}
    </div>
      `
    } catch (error) {
      console.error("Error", error);
      
    }
  }
  
}
